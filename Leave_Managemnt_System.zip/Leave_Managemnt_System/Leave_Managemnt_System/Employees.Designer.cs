﻿namespace Leave_Managemnt_System
{
    partial class Employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employees));
            this.EmpLeavelbl = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.categorylbl = new System.Windows.Forms.Label();
            this.Leavelbl = new System.Windows.Forms.Label();
            this.EmpLogoutlbl = new System.Windows.Forms.Label();
            this.Emplbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.EmpNameTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmpPhoneTb = new System.Windows.Forms.TextBox();
            this.AddressTb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.EditBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.EmpGenCb = new System.Windows.Forms.ComboBox();
            this.PasswordTb = new System.Windows.Forms.TextBox();
            this.EmployeesList = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.roleCb = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.EmpLeavelbl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeesList)).BeginInit();
            this.SuspendLayout();
            // 
            // EmpLeavelbl
            // 
            this.EmpLeavelbl.BackColor = System.Drawing.Color.RosyBrown;
            this.EmpLeavelbl.Controls.Add(this.label13);
            this.EmpLeavelbl.Controls.Add(this.pictureBox1);
            this.EmpLeavelbl.Controls.Add(this.categorylbl);
            this.EmpLeavelbl.Controls.Add(this.Leavelbl);
            this.EmpLeavelbl.Controls.Add(this.EmpLogoutlbl);
            this.EmpLeavelbl.Controls.Add(this.Emplbl);
            this.EmpLeavelbl.Controls.Add(this.panel3);
            this.EmpLeavelbl.Dock = System.Windows.Forms.DockStyle.Left;
            this.EmpLeavelbl.Location = new System.Drawing.Point(0, 0);
            this.EmpLeavelbl.Name = "EmpLeavelbl";
            this.EmpLeavelbl.Size = new System.Drawing.Size(158, 567);
            this.EmpLeavelbl.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.RosyBrown;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(42, 66);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 17);
            this.label13.TabIndex = 29;
            this.label13.Text = "Leave MS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(45, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // categorylbl
            // 
            this.categorylbl.AutoSize = true;
            this.categorylbl.BackColor = System.Drawing.Color.RosyBrown;
            this.categorylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.categorylbl.ForeColor = System.Drawing.Color.White;
            this.categorylbl.Location = new System.Drawing.Point(29, 314);
            this.categorylbl.Name = "categorylbl";
            this.categorylbl.Size = new System.Drawing.Size(97, 22);
            this.categorylbl.TabIndex = 27;
            this.categorylbl.Text = "Categories";
            this.categorylbl.Click += new System.EventHandler(this.categorylbl_Click);
            // 
            // Leavelbl
            // 
            this.Leavelbl.AutoSize = true;
            this.Leavelbl.BackColor = System.Drawing.Color.RosyBrown;
            this.Leavelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.Leavelbl.ForeColor = System.Drawing.Color.White;
            this.Leavelbl.Location = new System.Drawing.Point(33, 270);
            this.Leavelbl.Name = "Leavelbl";
            this.Leavelbl.Size = new System.Drawing.Size(68, 22);
            this.Leavelbl.TabIndex = 26;
            this.Leavelbl.Text = "Leaves";
            this.Leavelbl.Click += new System.EventHandler(this.Leavelbl_Click);
            // 
            // EmpLogoutlbl
            // 
            this.EmpLogoutlbl.AutoSize = true;
            this.EmpLogoutlbl.BackColor = System.Drawing.Color.RosyBrown;
            this.EmpLogoutlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.EmpLogoutlbl.ForeColor = System.Drawing.Color.White;
            this.EmpLogoutlbl.Location = new System.Drawing.Point(36, 524);
            this.EmpLogoutlbl.Name = "EmpLogoutlbl";
            this.EmpLogoutlbl.Size = new System.Drawing.Size(65, 22);
            this.EmpLogoutlbl.TabIndex = 25;
            this.EmpLogoutlbl.Text = "Logout";
            this.EmpLogoutlbl.Click += new System.EventHandler(this.EmpLogoutlbl_Click);
            // 
            // Emplbl
            // 
            this.Emplbl.AutoSize = true;
            this.Emplbl.BackColor = System.Drawing.Color.RosyBrown;
            this.Emplbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.Emplbl.ForeColor = System.Drawing.Color.White;
            this.Emplbl.Location = new System.Drawing.Point(29, 222);
            this.Emplbl.Name = "Emplbl";
            this.Emplbl.Size = new System.Drawing.Size(98, 22);
            this.Emplbl.TabIndex = 24;
            this.Emplbl.Text = "Employees";
            this.Emplbl.Click += new System.EventHandler(this.Emplbl_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.RosyBrown;
            this.panel3.Location = new System.Drawing.Point(158, 233);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(762, 10);
            this.panel3.TabIndex = 21;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RosyBrown;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(158, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(758, 38);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(247, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Leave Management System";
            // 
            // EmpNameTb
            // 
            this.EmpNameTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpNameTb.ForeColor = System.Drawing.Color.Gray;
            this.EmpNameTb.Location = new System.Drawing.Point(183, 101);
            this.EmpNameTb.Name = "EmpNameTb";
            this.EmpNameTb.Size = new System.Drawing.Size(166, 26);
            this.EmpNameTb.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.RosyBrown;
            this.label3.Location = new System.Drawing.Point(180, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Employees  Name";
            // 
            // EmpPhoneTb
            // 
            this.EmpPhoneTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpPhoneTb.ForeColor = System.Drawing.Color.Gray;
            this.EmpPhoneTb.Location = new System.Drawing.Point(575, 99);
            this.EmpPhoneTb.Name = "EmpPhoneTb";
            this.EmpPhoneTb.Size = new System.Drawing.Size(167, 26);
            this.EmpPhoneTb.TabIndex = 10;
            // 
            // AddressTb
            // 
            this.AddressTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTb.ForeColor = System.Drawing.Color.Gray;
            this.AddressTb.Location = new System.Drawing.Point(375, 177);
            this.AddressTb.Name = "AddressTb";
            this.AddressTb.Size = new System.Drawing.Size(160, 26);
            this.AddressTb.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.ForeColor = System.Drawing.Color.RosyBrown;
            this.label8.Location = new System.Drawing.Point(375, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Employees  Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.ForeColor = System.Drawing.Color.RosyBrown;
            this.label9.Location = new System.Drawing.Point(574, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Employees  Phone";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.ForeColor = System.Drawing.Color.RosyBrown;
            this.label10.Location = new System.Drawing.Point(180, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(146, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "Employees  Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.ForeColor = System.Drawing.Color.RosyBrown;
            this.label11.Location = new System.Drawing.Point(375, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 17);
            this.label11.TabIndex = 17;
            this.label11.Text = "Employees  Gender";
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.LightCoral;
            this.EditBtn.FlatAppearance.BorderColor = System.Drawing.Color.RosyBrown;
            this.EditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.EditBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.EditBtn.Location = new System.Drawing.Point(787, 99);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(117, 30);
            this.EditBtn.TabIndex = 18;
            this.EditBtn.Text = "Edit";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.Color.Red;
            this.DeleteBtn.FlatAppearance.BorderColor = System.Drawing.Color.RosyBrown;
            this.DeleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.DeleteBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteBtn.Location = new System.Drawing.Point(787, 186);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(117, 30);
            this.DeleteBtn.TabIndex = 19;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.Color.RosyBrown;
            this.SaveBtn.FlatAppearance.BorderColor = System.Drawing.Color.RosyBrown;
            this.SaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.SaveBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.SaveBtn.Location = new System.Drawing.Point(787, 144);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(117, 30);
            this.SaveBtn.TabIndex = 20;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.RosyBrown;
            this.panel4.Location = new System.Drawing.Point(161, 222);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(758, 5);
            this.panel4.TabIndex = 21;
            // 
            // EmpGenCb
            // 
            this.EmpGenCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.EmpGenCb.FormattingEnabled = true;
            this.EmpGenCb.ItemHeight = 20;
            this.EmpGenCb.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.EmpGenCb.Location = new System.Drawing.Point(375, 101);
            this.EmpGenCb.Name = "EmpGenCb";
            this.EmpGenCb.Size = new System.Drawing.Size(157, 28);
            this.EmpGenCb.TabIndex = 24;
            // 
            // PasswordTb
            // 
            this.PasswordTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTb.ForeColor = System.Drawing.Color.Gray;
            this.PasswordTb.Location = new System.Drawing.Point(183, 177);
            this.PasswordTb.Name = "PasswordTb";
            this.PasswordTb.Size = new System.Drawing.Size(163, 26);
            this.PasswordTb.TabIndex = 8;
            // 
            // EmployeesList
            // 
            this.EmployeesList.AllowUserToOrderColumns = true;
            this.EmployeesList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.EmployeesList.BackgroundColor = System.Drawing.Color.White;
            this.EmployeesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmployeesList.Location = new System.Drawing.Point(161, 270);
            this.EmployeesList.Name = "EmployeesList";
            this.EmployeesList.Size = new System.Drawing.Size(752, 297);
            this.EmployeesList.TabIndex = 25;
            this.EmployeesList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmployeesList_CellContentClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.ForeColor = System.Drawing.Color.RosyBrown;
            this.label5.Location = new System.Drawing.Point(574, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 17);
            this.label5.TabIndex = 53;
            this.label5.Text = "Role";
            // 
            // roleCb
            // 
            this.roleCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.roleCb.FormattingEnabled = true;
            this.roleCb.ItemHeight = 20;
            this.roleCb.Items.AddRange(new object[] {
            "Admin",
            "Employee"});
            this.roleCb.Location = new System.Drawing.Point(575, 177);
            this.roleCb.Name = "roleCb";
            this.roleCb.Size = new System.Drawing.Size(167, 28);
            this.roleCb.TabIndex = 52;
            this.roleCb.SelectedIndexChanged += new System.EventHandler(this.role_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.RosyBrown;
            this.label6.Location = new System.Drawing.Point(466, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 24);
            this.label6.TabIndex = 54;
            this.label6.Text = "Add Employees";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.RosyBrown;
            this.label2.Location = new System.Drawing.Point(466, 245);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 24);
            this.label2.TabIndex = 55;
            this.label2.Text = "Employees List";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // Employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(916, 567);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.roleCb);
            this.Controls.Add(this.EmployeesList);
            this.Controls.Add(this.EmpGenCb);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.AddressTb);
            this.Controls.Add(this.EmpPhoneTb);
            this.Controls.Add(this.PasswordTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.EmpNameTb);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.EmpLeavelbl);
            this.ForeColor = System.Drawing.Color.RosyBrown;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employees";
            this.EmpLeavelbl.ResumeLayout(false);
            this.EmpLeavelbl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeesList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel EmpLeavelbl;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox EmpNameTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox EmpPhoneTb;
        private System.Windows.Forms.TextBox AddressTb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Leavelbl;
        private System.Windows.Forms.Label EmpLogoutlbl;
        private System.Windows.Forms.Label Emplbl;
        private System.Windows.Forms.Label categorylbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox EmpGenCb;
        private System.Windows.Forms.TextBox PasswordTb;
        private System.Windows.Forms.DataGridView EmployeesList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox roleCb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
    }
}